﻿using OSFSample.Support.UI.Units;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : ShowcaseContent
    {
        public $safeitemname$()
        {
            this.InitializeComponent();
        }
    }
}