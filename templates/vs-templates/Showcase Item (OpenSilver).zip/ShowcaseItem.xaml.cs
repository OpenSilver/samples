using OpenSilverShowcase.Support.UI.Units;

namespace $rootnamespace$
{
    public partial class $fileinputname$ : ShowcaseItem
    {
        public $fileinputname$()
        {
            this.InitializeComponent();
        }
    }
}
